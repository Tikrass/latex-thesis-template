
tstat <- function(x,y,var,d, n) {
  1 - pnorm(abs((abs(x-y)-d)/sqrt(2*var/n)))
}

cat("UB\n")
for (i in 1:5) {
  cat(UB_baseline$mae[i] - UB_plain$mae[i], sep="\n")
}

d <- 0.05
for (i in 1:5) {
  cat(tstat(UB_baseline$mae[i], UB_plain$mae[i], UB_baseline$var[i],d, 5000), sep="\n")
}

cat("IB\n")

for (i in 1:5) {
  cat(IB_baseline$mae[i] - IB_plain$mae[i], sep="\n")
}

d <- 0.02
for (i in 1:5) {
  cat(tstat(IB_baseline$mae[i], IB_plain$mae[i], IB_baseline$var[i],d, 5000), sep="\n")
}


