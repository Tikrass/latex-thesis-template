setwd("~/Dokumente/Dokumente/Uni/SS17/MA/data")
UB_plain <- read.csv(file="./ubplain.csv", header=TRUE, sep="")
UB_baseline <- read.csv(file="./ubbaseline.csv", header=TRUE, sep="")
IB_plain <- read.csv(file="./ibplain.csv", header=TRUE, sep="")
IB_baseline <- read.csv(file="./ibbaseline.csv", header=TRUE, sep="")
UB_sparse <- read.csv(file="./ubsparse.csv", header=TRUE, sep="")

fitubplain <- lm(UB_plain$tmodel ~ poly(UB_plain$n, 2, raw=TRUE))
fitubbase <- lm(UB_baseline$tmodel ~ poly(UB_baseline$n, 2, raw=TRUE))

regubplain <- function(x) fitubplain$coefficient[3]*x^2 + fitubplain$coefficient[2]*x + fitubplain$coefficient[1]
curve(regubplain, from=UB_plain$n[1], to=UB_plain$n[5], col="red", lwd=2)
points(UB_plain$n,UB_plain$tmodel, type="p")

regubbase <- function(x) fitubbase$coefficient[3]*x^2 + fitubbase$coefficient[2]*x + fitubbase$coefficient[1]
curve(regubbase, from=UB_baseline$n[1], to=UB_baseline$n[5], col="red", lwd=2)
points(UB_baseline$n,UB_baseline$tmodel, type="p")

fitubpredplain <- lm(UB_plain$tpred ~ UB_plain$n)
fitubpredbase <- lm(UB_baseline$tpred ~ UB_baseline$n)

fitibplain <- lm(IB_plain$tmodel ~ poly(IB_plain$m, 2, raw=TRUE))
fitibbase <- lm(IB_baseline$tmodel ~ poly(IB_baseline$m, 2, raw=TRUE))

fitubsparse <- lm(UB_sparse$tmodel ~ poly(UB_sparse$c, 2, raw=TRUE))